const conn = require('../../config/mysql');

module.exports = (app) => {
    app.get('/estudiante', (req, res) => {
        let query = "SELECT * FROM estudiante";
        conn.query(query, (err, rows, fields) => {
            if (err) res.status(500).send("Error en el query");
            res.send(row);
        });
    });
    app.get('/estudiante/:id', (req, res) => {
        let query = "SELECT * FROM estudiante WHERE id = ${req.params.id}";
        conn.query(query, (err, rows, fields) => {
            if (err) res.status(500).send("Error en el query");
            res.send(row);
        });
    });
    app.post('/estudiante', (req, res) => {
        let query = "INSERT INTO  estudiante (nombre, direccion, fecha_nacimiento, saldo) VALUES ('${req.body.nombre}','${req.body.direccion}','${req.body.fecha_nacimiento}','${req.body.saldo}')";
        conn.query(query, (err, rows, fields) => {
            if (err) res.status(500).send("Error en el query");
            res.send(req.body);

        });
    });
    app.put('/estudiante/:id', (req, res) => {
        let query = "UPDATE * FROM estudiante WHERE id = ${req.params.id}";
        conn.query(query, (err, rows, fields) => {
            if (err) res.status(500).send("Error en el query");
            res.send(req.body);

        });
    });
    app.put('/estudiante/:id', (req, res) => {
        let query = "DELETE * FROM estudiante WHERE id = ${req.params.id}";
        conn.query(query, (err, rows, fields) => {
            if (err) res.status(500).send("Error en el query");
            res.send(req.body);

        });
    });
}