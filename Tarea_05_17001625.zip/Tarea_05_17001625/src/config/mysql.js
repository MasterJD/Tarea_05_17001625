const mysql = require('mysql');
const conn = mysql.createConnection({
    host: '18.217.14.101',
    user: 'awa_user',
    password: 'Abc12345',
    database: 'AWA'
});

conn.connect(err => {
    if (err) console.log("Problema en coneccion al MySQL");
    console.log('MySQL operando...');
});

module.exports = conn;
